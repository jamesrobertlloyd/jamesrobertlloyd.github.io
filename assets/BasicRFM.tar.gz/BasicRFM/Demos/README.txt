Change the working directory to Demos, then run highschool_predict.m

This shows very basic usage of the code, with some comments.

Please contact James Robert Lloyd (http://mlg.eng.cam.ac.uk/lloyd/) for more information if required.
