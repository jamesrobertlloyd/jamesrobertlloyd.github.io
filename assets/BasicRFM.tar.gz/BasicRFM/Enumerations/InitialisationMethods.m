classdef InitialisationMethods
  enumeration
    None, ResamplePseudo, MAPU, Both, PCA
  end
end



