classdef KernelPriors
  enumeration
    LogNormals, InverseGammas
  end
end



