classdef ObservationModels
  enumeration
    Gaussian, Logit, Poisson
  end
end



