classdef ExchangeabilityTypes
  enumeration
    Separately, Jointly
  end
end



