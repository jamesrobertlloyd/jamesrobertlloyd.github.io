classdef hcData < handle
  %hc2Data A MATLAB pointer hack
  % Contains
  %  - Data
  %
  % Written by James Lloyd, June 2012
  
  properties
    
    data
    
  end
  
end
