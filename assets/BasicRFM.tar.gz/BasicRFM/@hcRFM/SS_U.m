function SS_U( obj, width, step_out, max_attempts )
%SS_U Independently slice sample the latent node points
% Detailed explanation goes here
%
% James Lloyd, June 2012
  obj.slice_U (1, width, step_out, max_attempts);
end

