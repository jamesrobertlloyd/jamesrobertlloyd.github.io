function SS_V( obj, width, step_out, max_attempts )
%SS_V Independently slice sample the latent node points
% Detailed explanation goes here
%
% James Lloyd, June 2012
  obj.slice_V (1, width, step_out, max_attempts);
end

